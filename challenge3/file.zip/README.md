# OpenTofu + Oracle Cloud (OCI) — Simple Web Server

**What this repo does**

- Provision a single VM on Oracle Cloud Infrastructure (OCI) using **OpenTofu** (a Terraform fork).
- The VM launches, installs **Nginx** via cloud-init, and serves a simple **"Hello, OpenTofu!"** page.
- Security: firewall rules allow inbound HTTP (80) and SSH (22).
- Outputs the VM's **public IP** after `tofu apply`.

**Why OCI?**

- OCI offers a generous Always Free tier (VM.Standard.E2.1.Micro shapes). This makes it an easy, low-cost place to test infra-as-code. See OCI Free Tier docs. citeturn7search4turn7search0

**Why OpenTofu?**

- OpenTofu provides the same Terraform-style declarative IaC workflow with the CLI commands `tofu init`, `tofu plan`, `tofu apply`, `tofu destroy`. See OpenTofu docs. citeturn7search11turn7search1

---

## Quick start (fast, easy deployment)

1. Install OpenTofu (tofu) and OCI CLI + configure an OCI profile (or set environment variables).

   - OpenTofu docs: `tofu init`, `tofu apply`. citeturn7search11turn7search3
   - OCI Free Tier / CLI setup: https://www.oracle.com/cloud/free and OCI docs. citeturn7search4

2. Generate an SSH key if you don't have one:

```bash
ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa -N ""
```

3. Copy your tenancy & compartment OCIDs into a `terraform.tfvars` file, make sure this file is not add into git (use .gitignore for safety):

```hcl
tenancy_ocid = "ocid1.tenancy.oc1..aaaa..."
compartment_ocid = "ocid1.compartment.oc1..aaaa..."
# Optional
region = "ap-batam-1"
```

4. Initialize & apply:

```bash
# Initialize OpenTofu directory and provider plugins
tofu init

# Review planned changes
tofu plan

# Apply (create resources)
tofu apply
```

When complete, you'll see the `public_ip` output. (OpenTofu uses the same workflow as Terraform — `init`, `plan`, `apply`.)

5. SSH / Browse

```bash
ssh -i ~/.ssh/id_rsa opc@<PUBLIC_IP>
# or open http://<PUBLIC_IP> in your browser to see "Hello, OpenTofu!"
```

6. Destroy when done:

```bash
tofu destroy
```

---

## Files in this repo

- `versions.tf` — provider + required versions
- `provider.tf` — provider configuration (reads OCI CLI config/profile)
- `variables.tf` — reusable variables (region, shapes, OCIDs, SSH key path)
- `main.tf` — VCN, subnet, IGW, route table, security list, instance with cloud-init
- `outputs.tf` — prints the VM public IP and other useful info
- `cloud-init.sh` — startup script: installs nginx + small nginx tuning, optional node_exporter for observability
- `ci/github-actions.yml` — example GitHub Actions (how to run `tofu apply` safely)
- `LICENSE` and `.gitignore`

---

## Security / credentials (store securely)

- **Do not** hardcode OCIDs, private keys, or secrets in the repo.
- Use OCI CLI config file (`~/.oci/config`) with profiles or environment variables.
- For CI/CD, put sensitive values (OCI API keys, private keys, TF*VAR*\*) into GitHub Secrets / GitLab CI variables / Vault.
- I recommend using OCI's IAM + API keys for automation and keep keys in a secrets manager (HashiCorp Vault, GitHub Secrets, or OCI Vault).

---

## Observability & Backup (quick notes)

- The cloud-init installs `node_exporter` for Prometheus scraping (optional). You can scrape metrics from the VM or use OCI Monitoring/Logging for metrics and logs. For production, use a CNCF stack: Prometheus + Grafana + Alertmanager. (Prometheus is CNCF-hosted.) citeturn4search6turn7search19
- For backup: create boot volume backups or create a custom image of the boot volume (OCI supports boot volume backups). See the README section below for commands.

---

## Reasoning / design decisions (short)

1. **OCI Always Free** — free micro VM shape (VM.Standard.E2.1.Micro) is stable for small demos and tests; low/no-cost and widely available. citeturn7search0turn7search4
2. **OpenTofu** — compatible CLI workflow (`tofu init/apply/destroy`) and wide provider support; forks of Terraform are compatible. citeturn7search11
3. **Cloud-init & Nginx** — cloud-init ensures the instance is ready right after boot, no provisioners needed; Nginx is lightweight and fast for serving a static page. citeturn2search12
4. **Security lists (OCI)** — stateless network rules at the subnet level are simpler for demo; allow 22 & 80. For production use NSGs & stricter rules. citeturn0search2
5. **Observability** — node_exporter allows lightweight scraping; recommend central Prometheus for aggregation (CNCF).

---

## Diagrams (topology)

```
           Internet
              |
           Public IP
              |
         OCI Internet Gateway
              |
         Route Table (0.0.0.0/0 -> IGW)
              |
        VCN (10.0.0.0/16)
              |
         Public Subnet (10.0.1.0/24)
              |
        OCI Instance (assign_public_ip = true)
         - nginx (80)
         - ssh  (22)
         - node_exporter (9100) [optional]
```
